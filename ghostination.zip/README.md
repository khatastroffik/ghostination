# Ghostination

A content focused responsive theme for "personal" [Ghost](https://github.com/tryghost/ghost/) blogs.

## Screenshots

## Features

* Responsive layout
* Dark Mode (based on the user preference at OS level)
* Search (to be manually enabled; see instructions below)
* Post reading progress
* Code highlight including line numbers
* Disqus support

## Ghost Compatibility

The theme has been tested within a Docker image running Ghost version **3.12.1**.

It should work fine with versions **>= 3.\*** (no warranty, though).

## Setup search

The search function is an integration of the open source [ghostHunter](https://github.com/jamalneufeld/ghostHunter). It is based on a pure *client side* engine.

1. Go to __Integrations__.  
1. Choose __Add custom integration__, name it `ghostHunter` and choose __Create__. Copy the generated Content API Key.  
1. Go to __Code injection__.  
1. Add this to __Blog Header__:  

````
<script>
  var ghosthunter_key = 'PASTE_THE_GENERATED_KEY_HERE';
  //optional: set your custom ghost_root url, default is "/ghost/api/v2"
  var ghost_root_url = '/ghost/api/v2';
</script>
````

## Development

Install [Grunt](https://gruntjs.com/getting-started/):

	npm install -g grunt-cli

Install Grunt dependencies:

	npm install

Build Grunt project:

	grunt build

The compress Grunt task packages the theme files into `dist/<theme-name>.zip`, which you can then upload to your site.

	grunt compress

## License & Copyrights

**Ghostination** is released under the [MIT License](https://opensource.org/licenses/MIT).

See the [LICENSE](./LICENSE) file .

## Credits

This theme is based on the [Attila Theme](https://github.com/zutrinken/attila) by [Peter Amende](https://github.com/zutrinken): **Thank you Peter!**